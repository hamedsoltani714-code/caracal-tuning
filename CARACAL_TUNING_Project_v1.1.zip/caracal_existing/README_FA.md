# CARACAL TUNING — نسخه 1.1.0

اپلیکیشن Flutter برای آموزش و مرجع اطلاعات فنی خودرو.

## امکانات پیاده‌سازی‌شده در این نسخه
- رابط تیره با هویت بصری مشکی و نقره‌ای
- تغییر زبان رابط بین فارسی و انگلیسی
- ۱۴ بخش تخصصی قابل جست‌وجو
- صفحه جزئیات و سرفصل برای هر بخش
- ذخیره و حذف علاقه‌مندی‌ها روی دستگاه
- صفحه درباره برنامه
- ساخت APK با GitHub Actions

## اجرای پروژه
به Flutter SDK و Dart سازگار با نسخه درج‌شده در `pubspec.yaml` نیاز دارید:

```bash
flutter create . --platforms=android --org com.caracal.tuning
flutter pub get
flutter run
```

## ساخت APK
```bash
flutter build apk --release
```
فایل خروجی: `build/app/outputs/flutter-apk/app-release.apk`

یا فایل‌ها را در شاخه `main` مخزن GitHub بارگذاری کنید؛ Workflow موجود در مسیر `.github/workflows/build-apk.yml` با هر push یا اجرای دستی، APK را می‌سازد. خروجی در بخش Actions و قسمت Artifacts با نام `caracal-tuning-apk` قرار می‌گیرد.

## وضعیت اتصال سرور
ساختار اولیه Supabase در `supabase/migrations/0001_initial_schema.sql` نگهداری شده است؛ اتصال زنده، ورود کاربران، داده‌های واقعی خودرو و کدهای DTC هنوز پیکربندی و اعتبارسنجی نشده‌اند. کلید `service_role` را هرگز داخل اپلیکیشن قرار ندهید.
