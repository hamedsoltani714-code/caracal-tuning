-- CARACAL TUNING initial Supabase schema
-- Run in Supabase SQL Editor. RLS is enabled; public technical records are readable.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  preferred_language text not null default 'fa' check (preferred_language in ('fa','en')),
  created_at timestamptz not null default now()
);

create table if not exists public.manufacturers (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  created_at timestamptz not null default now()
);

create table if not exists public.vehicles (
  id uuid primary key default gen_random_uuid(),
  manufacturer_id uuid not null references public.manufacturers(id) on delete restrict,
  model text not null,
  generation text,
  production_year_from integer,
  production_year_to integer,
  engine_code text,
  engine_type text,
  transmission_type text,
  fuel_type text,
  created_at timestamptz not null default now(),
  check (production_year_to is null or production_year_from is null or production_year_to >= production_year_from)
);

create table if not exists public.dtc_codes (
  id uuid primary key default gen_random_uuid(),
  code text not null,
  title_fa text,
  title_en text,
  description_fa text,
  description_en text,
  category text,
  is_generic boolean not null default true,
  manufacturer_id uuid references public.manufacturers(id) on delete set null,
  verification_status text not null default 'unverified'
    check (verification_status in ('unverified','reviewed','verified')),
  created_at timestamptz not null default now(),
  unique (code, manufacturer_id)
);

create table if not exists public.learning_content (
  id uuid primary key default gen_random_uuid(),
  title_fa text,
  title_en text,
  body_fa text,
  body_en text,
  content_type text not null check (content_type in ('article','video','pdf','diagram')),
  storage_path text,
  is_premium boolean not null default false,
  published boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.favorites (
  user_id uuid not null references auth.users(id) on delete cascade,
  content_id uuid not null references public.learning_content(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, content_id)
);

create table if not exists public.user_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  content_id uuid not null references public.learning_content(id) on delete cascade,
  completed boolean not null default false,
  updated_at timestamptz not null default now(),
  primary key (user_id, content_id)
);

create index if not exists vehicles_model_idx on public.vehicles(model);
create index if not exists dtc_codes_code_idx on public.dtc_codes(code);
create index if not exists learning_content_published_idx on public.learning_content(published, created_at desc);

alter table public.profiles enable row level security;
alter table public.manufacturers enable row level security;
alter table public.vehicles enable row level security;
alter table public.dtc_codes enable row level security;
alter table public.learning_content enable row level security;
alter table public.favorites enable row level security;
alter table public.user_progress enable row level security;

create policy "Users can view own profile" on public.profiles
  for select to authenticated using (auth.uid() = id);
create policy "Users can insert own profile" on public.profiles
  for insert to authenticated with check (auth.uid() = id);
create policy "Users can update own profile" on public.profiles
  for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

create policy "Manufacturers readable by everyone" on public.manufacturers
  for select to anon, authenticated using (true);
create policy "Vehicles readable by everyone" on public.vehicles
  for select to anon, authenticated using (true);
create policy "DTC codes readable by everyone" on public.dtc_codes
  for select to anon, authenticated using (true);
create policy "Published content readable" on public.learning_content
  for select to anon, authenticated using (published = true and is_premium = false);

create policy "Users manage own favorites" on public.favorites
  for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users manage own progress" on public.user_progress
  for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Admin write access must be added only after a trusted server-side role design is configured.
