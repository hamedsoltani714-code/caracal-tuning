import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  runApp(CaracalApp(prefs: prefs));
}

const Color _bg = Color(0xFF08090A);
const Color _panel = Color(0xFF151719);
const Color _silver = Color(0xFFBFC3C7);

class CaracalApp extends StatefulWidget {
  const CaracalApp({super.key, required this.prefs});
  final SharedPreferences prefs;
  @override
  State<CaracalApp> createState() => _CaracalAppState();
}

class _CaracalAppState extends State<CaracalApp> {
  String language = 'fa';
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'CARACAL TUNING',
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          scaffoldBackgroundColor: _bg,
          colorScheme: const ColorScheme.dark(primary: _silver, secondary: Colors.white, surface: _panel),
          appBarTheme: const AppBarTheme(backgroundColor: _bg, foregroundColor: Colors.white),
          cardTheme: CardTheme(
            color: _panel,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: const BorderSide(color: Color(0xFF34383B))),
          ),
        ),
        home: HomeScreen(
          prefs: widget.prefs,
          language: language,
          onLanguageChanged: (value) => setState(() => language = value),
        ),
      );
}

class Module {
  const Module(this.fa, this.en, this.icon, this.summaryFa, this.summaryEn, this.pointsFa, this.pointsEn);
  final String fa, en;
  final IconData icon;
  final String summaryFa, summaryEn;
  final List<String> pointsFa, pointsEn;
}

const modules = <Module>[
  Module('آموزش فنی خودرو', 'Automotive Education', Icons.school_outlined,
    'مسیر یادگیری ساختارمند برای شناخت سامانه‌های اصلی خودرو.', 'A structured learning path for core vehicle systems.',
    ['مبانی موتور و احتراق', 'مبانی برق و الکترونیک خودرو', 'روش مطالعه نقشه‌ها و مستندات فنی'],
    ['Engine and combustion fundamentals', 'Automotive electrical fundamentals', 'Reading technical diagrams and documentation']),
  Module('بانک اطلاعات خودرو', 'Vehicle Database', Icons.directions_car_outlined,
    'مرجع مشخصات خودرو، موتور و واحد کنترل الکترونیکی.', 'Reference for vehicle, engine and ECU specifications.',
    ['سازنده و مدل خودرو', 'کد موتور و نوع سوخت', 'شناسه ECU و نسخه نرم‌افزار'],
    ['Manufacturer and model', 'Engine code and fuel type', 'ECU identifier and software version']),
  Module('کدهای خطای DTC', 'DTC Error Codes', Icons.error_outline,
    'آشنایی با ساختار کدهای عیب‌یابی و روش تفسیر آن‌ها.', 'Understand diagnostic trouble codes and their interpretation.',
    ['ساختار عمومی کدهای خطا', 'تفاوت کد خطا و علت ریشه‌ای', 'بررسی داده زنده و شرایط ثبت خطا'],
    ['Generic trouble-code structure', 'Difference between a code and root cause', 'Live data and freeze-frame context']),
  Module('نقشه پایه‌های ECU', 'ECU Pinouts', Icons.memory_outlined,
    'شناخت کانکتورها و ارجاع صحیح به مستندات سازنده.', 'Understand connectors and use manufacturer documentation.',
    ['شماره‌گذاری کانکتورها', 'شناخت ورودی، خروجی و تغذیه', 'تطبیق شماره قطعه و نسخه سخت‌افزار'],
    ['Connector numbering', 'Inputs, outputs and power circuits', 'Matching part number and hardware revision']),
  Module('نقشه سیم‌کشی', 'Wiring Diagrams', Icons.account_tree_outlined,
    'خواندن علائم، مسیرها و ارتباط اجزای مدار.', 'Read symbols, circuit paths and component relationships.',
    ['علائم و اختصارات رایج', 'مسیر تغذیه و اتصال بدنه', 'شناخت فیوزها و نقاط اتصال'],
    ['Common symbols and abbreviations', 'Power and ground paths', 'Fuses and connection points']),
  Module('فیوز و رله', 'Fuses & Relays', Icons.electrical_services,
    'آشنایی با حفاظت مدار و نقش رله‌ها در خودرو.', 'Learn circuit protection and relay functions.',
    ['وظیفه فیوز در حفاظت مدار', 'ساختار عملکرد رله', 'لزوم استفاده از مقدار نامی صحیح'],
    ['Fuse protection', 'Relay operation', 'Using the correct rated replacement']),
  Module('تعمیرات موتور', 'Engine Repair', Icons.settings_outlined,
    'مروری بر سازوکار موتور و اصول بررسی عیب.', 'Overview of engine operation and fault assessment.',
    ['چرخه‌های کاری موتور', 'روانکاری و خنک‌کاری', 'اندازه‌گیری و ارزیابی طبق دستورالعمل سازنده'],
    ['Engine operating cycles', 'Lubrication and cooling', 'Measurements using manufacturer procedures']),
  Module('سیستم برق خودرو', 'Automotive Electrical', Icons.bolt,
    'مبانی باتری، شارژ، استارت و مدارهای الکتریکی.', 'Fundamentals of battery, charging, starting and circuits.',
    ['مبانی ولتاژ و جریان', 'باتری و سیستم شارژ', 'اصول ایمنی اندازه‌گیری'],
    ['Voltage and current basics', 'Battery and charging system', 'Safe measurement principles']),
  Module('گیربکس اتوماتیک', 'Automatic Transmission', Icons.sync,
    'آشنایی با اجزا و منطق کلی کنترل انتقال قدرت.', 'Understand components and transmission control basics.',
    ['اجزای اصلی گیربکس', 'نقش سنسورها و عملگرها', 'اهمیت روغن و سرویس استاندارد'],
    ['Main transmission components', 'Sensors and actuators', 'Fluid and scheduled service']),
  Module('سنسورها و عملگرها', 'Sensors & Actuators', Icons.sensors,
    'شناخت ورودی‌ها و خروجی‌های سامانه مدیریت موتور.', 'Understand engine-management inputs and outputs.',
    ['انواع سیگنال حسگرها', 'تفاوت حسگر و عملگر', 'مقایسه داده با شرایط واقعی کارکرد'],
    ['Sensor signal types', 'Sensors versus actuators', 'Compare data with actual operating conditions']),
  Module('فرهنگ لغات تخصصی', 'Technical Dictionary', Icons.menu_book,
    'واژه‌های رایج فنی خودرو به فارسی و انگلیسی.', 'Common automotive technical terms in Persian and English.',
    ['ECU — واحد کنترل الکترونیکی', 'DTC — کد عیب‌یابی', 'PID — شناسه پارامتر داده'],
    ['ECU — Electronic Control Unit', 'DTC — Diagnostic Trouble Code', 'PID — Parameter Identifier']),
  Module('ماشین‌حساب‌ها', 'Automotive Calculators', Icons.calculate_outlined,
    'ابزارهای محاسباتی آموزشی برای مفاهیم پایه.', 'Educational calculators for basic engineering concepts.',
    ['تبدیل واحدهای رایج', 'قانون اهم و توان الکتریکی', 'محاسبات آموزشی؛ نه جایگزین مشخصات سازنده'],
    ['Common unit conversions', 'Ohm’s law and electrical power', 'Educational calculations, not manufacturer specifications']),
  Module('دستیار عیب‌یابی', 'Diagnostic Assistant', Icons.smart_toy_outlined,
    'راهنمای مرحله‌ای برای ثبت نشانه‌ها و سازمان‌دهی بررسی‌ها.', 'A guided workflow to record symptoms and organize checks.',
    ['ثبت دقیق نشانه و شرایط بروز', 'بررسی کدها همراه با داده زنده', 'تأیید نتیجه با روش آزمون معتبر'],
    ['Record symptoms and conditions', 'Review codes with live data', 'Verify with a valid test procedure']),
  Module('آزمون‌های تخصصی', 'Technical Quizzes', Icons.quiz_outlined,
    'بخش تمرین و سنجش دانش فنی در نسخه‌های بعدی تکمیل می‌شود.', 'Practice and knowledge checks will be expanded in a later release.',
    ['آزمون‌های موضوعی', 'نمایش پاسخ و توضیح آموزشی', 'ثبت روند پیشرفت'],
    ['Topic-based quizzes', 'Answers with explanations', 'Progress tracking']),
];

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.prefs, required this.language, required this.onLanguageChanged});
  final SharedPreferences prefs;
  final String language;
  final ValueChanged<String> onLanguageChanged;
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;
  String query = '';
  List<String> get favorites => widget.prefs.getStringList('favorites') ?? [];
  bool get fa => widget.language == 'fa';

  @override
  Widget build(BuildContext context) {
    final visible = modules.where((m) => '${m.fa} ${m.en} ${m.summaryFa} ${m.summaryEn}'.toLowerCase().contains(query.toLowerCase())).toList();
    return Directionality(
      textDirection: fa ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('CARACAL TUNING', style: TextStyle(letterSpacing: 1.5, fontWeight: FontWeight.w900)),
          actions: [
            IconButton(tooltip: fa ? 'تغییر زبان' : 'Change language', onPressed: () => widget.onLanguageChanged(fa ? 'en' : 'fa'), icon: const Icon(Icons.language)),
            IconButton(tooltip: fa ? 'علاقه‌مندی‌ها' : 'Favorites', onPressed: () => setState(() => tab = 1), icon: const Icon(Icons.bookmark_border)),
          ],
        ),
        body: IndexedStack(index: tab, children: [
          _dashboard(visible),
          _favorites(),
          _about(),
        ]),
        bottomNavigationBar: NavigationBar(
          backgroundColor: _panel,
          selectedIndex: tab,
          onDestinationSelected: (v) => setState(() => tab = v),
          destinations: [
            NavigationDestination(icon: const Icon(Icons.home_outlined), selectedIcon: const Icon(Icons.home), label: fa ? 'خانه' : 'Home'),
            NavigationDestination(icon: const Icon(Icons.bookmarks_outlined), selectedIcon: const Icon(Icons.bookmarks), label: fa ? 'ذخیره‌شده' : 'Saved'),
            NavigationDestination(icon: const Icon(Icons.info_outline), label: fa ? 'درباره' : 'About'),
          ],
        ),
      ),
    );
  }

  Widget _dashboard(List<Module> visible) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: const LinearGradient(colors: [Color(0xFF34383B), Color(0xFF101112)], begin: Alignment.topLeft, end: Alignment.bottomRight),
          border: Border.all(color: const Color(0xFF777777)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Icon(Icons.speed, size: 42, color: _silver),
          const SizedBox(height: 12),
          const Text('CARACAL TUNING', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          const Text('DRIVE • LEARN • UPGRADE', style: TextStyle(letterSpacing: 2, color: _silver)),
          const SizedBox(height: 14),
          Text(fa ? 'پلتفرم تخصصی دانش و فناوری خودرو' : 'Automotive knowledge & technology platform'),
        ]),
      ),
      const SizedBox(height: 18),
      TextField(
        onChanged: (v) => setState(() => query = v.trim()),
        decoration: InputDecoration(
          hintText: fa ? 'جستجو در بخش‌های تخصصی...' : 'Search technical modules...',
          prefixIcon: const Icon(Icons.search), filled: true, fillColor: _panel,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        ),
      ),
      const SizedBox(height: 22),
      Text(fa ? 'بخش‌های تخصصی' : 'TECHNICAL MODULES', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      GridView.builder(
        shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: visible.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.18),
        itemBuilder: (context, index) {
          final module = visible[index];
          return InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ModulePage(module: module, fa: fa, isFavorite: favorites.contains(module.fa), onFavorite: () => _toggleFavorite(module)))),
            child: Card(child: Padding(padding: const EdgeInsets.all(13), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Icon(module.icon, size: 29, color: _silver),
              Text(fa ? module.fa : module.en, style: const TextStyle(fontWeight: FontWeight.w700)),
              Text(fa ? 'مشاهده بخش' : 'Open module', style: TextStyle(fontSize: 11, color: Colors.grey.shade500)),
            ]))),
          );
        },
      ),
      if (visible.isEmpty) Padding(padding: const EdgeInsets.all(24), child: Center(child: Text(fa ? 'نتیجه‌ای پیدا نشد.' : 'No results found.'))),
      const SizedBox(height: 20),
      Center(child: Text('DRIVE • LEARN • UPGRADE', style: TextStyle(color: Colors.grey.shade600, letterSpacing: 1.5))),
    ],
  );

  Widget _favorites() {
    final saved = modules.where((m) => favorites.contains(m.fa)).toList();
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text(fa ? 'بخش‌های ذخیره‌شده' : 'Saved modules', style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
      const SizedBox(height: 14),
      if (saved.isEmpty) Center(child: Padding(padding: const EdgeInsets.all(32), child: Text(fa ? 'هنوز بخشی ذخیره نکرده‌ای.' : 'You have not saved any modules yet.'))),
      ...saved.map((m) => Card(child: ListTile(leading: Icon(m.icon, color: _silver), title: Text(fa ? m.fa : m.en), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ModulePage(module: m, fa: fa, isFavorite: true, onFavorite: () => _toggleFavorite(m))))))),
    ]);
  }

  Widget _about() => ListView(padding: const EdgeInsets.all(20), children: [
    const Icon(Icons.speed, size: 58, color: _silver),
    const SizedBox(height: 16),
    const Text('CARACAL TUNING', textAlign: TextAlign.center, style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
    const SizedBox(height: 12),
    Text(fa ? 'نسخه اولیه پلتفرم آموزش و مرجع فنی خودرو. اطلاعات فنی باید با مستندات رسمی و مشخصات دقیق خودرو تطبیق داده شوند.' : 'An early version of an automotive learning and technical reference platform. Technical information must be checked against official documentation and exact vehicle specifications.', textAlign: TextAlign.center, style: const TextStyle(height: 1.8, color: Colors.white70)),
    const SizedBox(height: 20),
    const ListTile(leading: Icon(Icons.verified_user_outlined), title: Text('Version 1.1.0'), subtitle: Text('Offline learning interface')),
  ]);

  Future<void> _toggleFavorite(Module module) async {
    final next = [...favorites];
    if (next.contains(module.fa)) { next.remove(module.fa); } else { next.add(module.fa); }
    await widget.prefs.setStringList('favorites', next);
    if (mounted) setState(() {});
  }
}

class ModulePage extends StatelessWidget {
  const ModulePage({super.key, required this.module, required this.fa, required this.isFavorite, required this.onFavorite});
  final Module module;
  final bool fa;
  final bool isFavorite;
  final VoidCallback onFavorite;

  @override
  Widget build(BuildContext context) {
    final points = fa ? module.pointsFa : module.pointsEn;
    return Directionality(
      textDirection: fa ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Text(fa ? module.fa : module.en), actions: [IconButton(onPressed: onFavorite, icon: Icon(isFavorite ? Icons.bookmark : Icons.bookmark_border))]),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFF34383B))), child: Icon(module.icon, size: 52, color: _silver)),
          const SizedBox(height: 20),
          Text(fa ? module.fa : module.en, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          Text(fa ? module.summaryFa : module.summaryEn, style: const TextStyle(height: 1.8, color: Colors.white70)),
          const SizedBox(height: 24),
          Text(fa ? 'سرفصل‌های این بخش' : 'Topics in this module', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          ...points.asMap().entries.map((entry) => Card(child: ListTile(leading: CircleAvatar(backgroundColor: const Color(0xFF34383B), child: Text('${entry.key + 1}')), title: Text(entry.value)))),
          const SizedBox(height: 18),
          Text(fa ? 'یادآوری: این سرفصل‌ها محتوای آموزشی اولیه‌اند و جایگزین دستورالعمل تعمیراتی سازنده، نقشه مخصوص خودرو یا آموزش عملی زیر نظر متخصص نیستند.' : 'Note: These are introductory learning topics, not a replacement for manufacturer service information or supervised hands-on training.', style: const TextStyle(color: Colors.orangeAccent, height: 1.8, fontSize: 12)),
        ]),
      ),
    );
  }
}
